package com.example.final_project.repository.detection;

import com.example.final_project.model.detection.DetectionEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DetectionRepository extends JpaRepository<DetectionEntity, Long> {
    DetectionEntity findOneByLicensePlateFound (String licensePlateFound);
}
