package com.example.final_project.business.userScore;

import org.springframework.stereotype.Component;

@Component
public class UserScoreBusiness {

}
