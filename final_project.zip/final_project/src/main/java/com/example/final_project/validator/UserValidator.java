package com.example.final_project.validator;

import com.example.final_project.model.user.UserEntity;
import org.springframework.stereotype.Component;

@Component
public class UserValidator {
    public void validateUserLoginAndPassword(UserEntity userEntity, String password) {
        if (userEntity == null) {
            throw new IllegalArgumentException("User Not found");
        }
        else if (!(userEntity.getPassword().equals(password))) {
            throw new IllegalArgumentException("Wrong password");
        }
    }
    public void validateUserRegister(UserEntity userEntity, String plate) {
        if (userEntity != null && userEntity.getStudentID() != null) {
            throw new IllegalArgumentException("Duplicate StudentID");
        }
        if (userEntity != null && !userEntity.getLicensePlate().equals(plate)) {
            throw new IllegalArgumentException("Duplicate license plate");
        }
    }
}
