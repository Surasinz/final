package com.example.final_project.business.user;

import org.springframework.stereotype.Component;

@Component
public class UserBusiness {

}
