package com.example.final_project.converter.detection;

import com.example.final_project.model.detection.DetectionEntity;
import com.example.final_project.model.detection.DetectionResponse;
import org.springframework.stereotype.Component;


import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class DetectionConverter {
    public List<DetectionResponse> entitiesToResponses(List<DetectionEntity> detectionEntities, String name) {
        return detectionEntities.stream()
                .map(detectionEntity -> entityToResponse(detectionEntity, name))
                .collect(Collectors.toList());
    }

    public DetectionResponse entityToResponse(DetectionEntity detectionEntity, String name) {
        DetectionResponse response = new DetectionResponse();
        response.setName(name);
        response.setEvidence(detectionEntity.getEvidenceImg());
        response.setDate(String.valueOf(detectionEntity.getDetectionTime().getDayOfMonth()));
        response.setMonth(String.valueOf(detectionEntity.getDetectionTime().getMonthValue()));
        response.setTime(Time.valueOf(detectionEntity.getDetectionTime().toLocalTime()));
        return response;
    }

    public List<DetectionResponse> entitiesToResponses(List<DetectionEntity> detectionEntities, List<String> names) {
        if (detectionEntities.size() != names.size()) {
            throw new IllegalArgumentException("Number of entities and names do not match");
        }

        List<DetectionResponse> responseList = new ArrayList<>();
        for (int i = 0; i < detectionEntities.size(); i++) {
            DetectionEntity detectionEntity = detectionEntities.get(i);
            String name = names.get(i);
            DetectionResponse response = entityToResponse(detectionEntity, name);
            responseList.add(response);
        }
        return responseList;
    }
}
