package com.example.final_project.converter.detection;

import com.example.final_project.model.detection.DetectionEntity;
import com.example.final_project.model.detection.DetectionResponse;
import org.springframework.stereotype.Component;


import java.sql.Time;
@Component
public class DetectionConverter {
    public DetectionResponse entityToResponse(DetectionEntity detectionEntity,String name) {
        DetectionResponse response = new DetectionResponse();
        response.setName(name);
        response.setEvidence(detectionEntity.getEvidenceImg());
        response.setDate(String.valueOf(detectionEntity.getDetectionTime().getDayOfMonth()));
        response.setMonth(String.valueOf(detectionEntity.getDetectionTime().getMonthValue()));
        response.setTime(Time.valueOf(detectionEntity.getDetectionTime().toLocalTime()));
        return response;
    }
}
