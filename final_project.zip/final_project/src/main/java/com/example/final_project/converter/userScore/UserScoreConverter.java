package com.example.final_project.converter.userScore;

import com.example.final_project.model.user.UserEntity;
import com.example.final_project.model.user.UserLoginResponse;
import com.example.final_project.model.userScore.UserScoreEntity;
import com.example.final_project.model.userScore.UserScoreResponse;
import com.example.final_project.repository.user.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UserScoreConverter {

    public UserScoreResponse entityToResponse(UserScoreEntity userScoreEntity,String name) {
        UserScoreResponse response = new UserScoreResponse();
        response.setName(name);
        response.setScore(userScoreEntity.getScore());
        return response;
    }
}
