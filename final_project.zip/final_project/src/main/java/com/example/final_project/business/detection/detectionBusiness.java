package com.example.final_project.business.detection;

import org.springframework.stereotype.Component;

@Component
public class detectionBusiness {
}
