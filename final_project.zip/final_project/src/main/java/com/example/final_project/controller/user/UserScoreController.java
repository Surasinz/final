package com.example.final_project.controller.user;

import com.example.final_project.converter.userScore.UserScoreConverter;
import com.example.final_project.model.userScore.UserScoreEntity;
import com.example.final_project.model.userScore.UserScoreResponse;
import com.example.final_project.repository.user.UserRepository;
import com.example.final_project.repository.userScore.UserScoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserScoreController {
    @Autowired
    UserRepository userRepository;
    @Autowired
    UserScoreRepository userScoreRepository;
    @Autowired
    UserScoreConverter userScoreConverter;
    @GetMapping("/api/userScore")
    public UserScoreResponse getUserByLicensePlateAndProvince(@RequestParam Long userId) {
        String name = userRepository.findNameByUserId(userId);
        UserScoreEntity userScoreEntity = userScoreRepository.findByUserId(userId);
        return (userScoreConverter.entityToResponse(userScoreEntity,name));
    }
}
