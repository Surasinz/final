package com.example.final_project.controller.user;

import com.example.final_project.converter.detection.DetectionConverter;
import com.example.final_project.model.detection.DetectionEntity;
import com.example.final_project.model.detection.DetectionResponse;
import java.util.stream.Collectors;
import com.example.final_project.repository.detection.DetectionRepository;
import com.example.final_project.repository.user.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class DetectionController {
    @Autowired
    private DetectionResponse detectionResponse;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private DetectionConverter detectionConverter;

    @Autowired
    private DetectionRepository detectionRepository;


    @GetMapping("/api/detection")
    public List<DetectionResponse> getUserByLicensePlateAndProvince(@RequestParam String licensePlate, @RequestParam String province) {
        List<DetectionEntity> detectionEntity = detectionRepository.findAllByLicensePlateFound(licensePlate);
        String name = userRepository.findNameByLicensePlateAndProvince(licensePlate, province);
        return detectionConverter.entitiesToResponses(detectionEntity, name);
    }


    @GetMapping("/api/detection/all")
    public List<DetectionResponse> getAllDetections() {
        List<DetectionEntity> detectionEntities = detectionRepository.findAll();
        List<Long> userIds = detectionEntities.stream()
                .map(DetectionEntity::getUserDetection)
                .collect(Collectors.toList());
        List<String> names = userRepository.findAllNamesByUserIds(userIds);
        return detectionConverter.entitiesToResponses(detectionEntities, names);
    }

}
