package com.example.final_project.controller.user;

import com.example.final_project.converter.detection.DetectionConverter;
import com.example.final_project.model.detection.DetectionEntity;
import com.example.final_project.model.detection.DetectionResponse;
import com.example.final_project.model.user.UserEntity;
import com.example.final_project.repository.detection.DetectionRepository;
import com.example.final_project.repository.user.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DetectionController {
    @Autowired
    private DetectionResponse detectionResponse;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private DetectionConverter detectionConverter;

    @Autowired
    private DetectionRepository detectionRepository;

    @GetMapping("/api/detection")
    public DetectionResponse getUserByLicensePlateAndProvince(@RequestParam String licensePlate, @RequestParam String province) {
        String name = userRepository.findNameByLicensePlateAndProvince(licensePlate,province);
        DetectionEntity detectionEntity = detectionRepository.findOneByLicensePlateFound(licensePlate);
        return (detectionConverter.entityToResponse(detectionEntity,name));
    }
}
